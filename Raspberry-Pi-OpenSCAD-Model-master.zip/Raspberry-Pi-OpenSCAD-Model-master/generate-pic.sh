#!/bin/bash
openscad -o rpi.png --camera=-30,0,12,41,0,201,620  --imgsize=640,480 --projection=p rpi.scad