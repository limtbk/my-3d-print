Raspberry-Pi-OpenSCAD-Model
===========================
Some dimensions taked from http://www.raspberrypi-spy.co.uk/2012/03/mechanical-data-dimensions/ others directly measured.
![Raspberry Pi](rpi.png?raw=true)

