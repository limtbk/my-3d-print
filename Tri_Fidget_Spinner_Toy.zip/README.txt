                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1802260
Tri Fidget Spinner Toy by 2ROBOTGUY is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

UPDATE-
6/10/17: Featured in spyder3dworld https://www.spyder3dworld.com/spinning-out-of-control/
2/17/17: Check out my Esty Store http://etsy.com/shop/MrFidgetByMark
2/17/17: Finger Pad V2 Twisted Pins Added
2/16/17: Free contest to Win these Fidget Spinners https://youtu.be/kn49MOOfuHg

12/15/2016: By request 2D drawings have been added
11/112015 Version 2 released : Smoother edges 
10/20/2016 Added a ready to print stl with all 3 parts.

Do you like this design and want more great projects? Donate a dollar or two to help order future supplies :-) http://bit.ly/2kbP40C

 Want to mail me something? It may show up in a future unboxing video (include note) 
Mark Fuller - PMB 163
463 Pooler Parkway
Pooler, Ga 31322

Video :https://youtu.be/NOGPQmb8KG8

All tolerances are exact and ball bearings need to be press fit in with a vise or equivalent device.  If plastic cracks, increase stl model by 1-2 percent and print again. Standard 608ZZ Shielded 8x22x7 Miniature Ball Bearings used in this model. The center Bearing can be switched for a 608ZZ/C Ceramic Ball Bearing for increase spin time. 

Spin on!

# Print Settings

Rafts: No
Supports: No
Resolution: 0.15mm
Infill: 100%

Notes: 
For great results print this model at 0.15mm layers, 6 shells and 100% infill